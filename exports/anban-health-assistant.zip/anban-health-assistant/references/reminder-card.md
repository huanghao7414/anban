# 大字卡、朗读稿与提醒

生成之前逐项展示并取得用户对当前内容的确认。`confirmed: true` 是调用方对人工核对状态的记录，脚本不能验证用户是否真的确认，模型不得自行补成 true。

输入结构：

```json
{
  "person": "长辈称呼",
  "date": "2026-11-21",
  "daily": true,
  "demo": false,
  "medications": [
    {"name": "用户已确认的药名", "dose": "用户已确认的每次用量", "time": "08:00", "meal": "用户已核对的吃饭关系", "confirmed": true},
    {"name": "另一盒已确认药名", "dose": "用户已确认的每次用量", "time": "18:00", "meal": "", "confirmed": true}
  ]
}
```

`date` 为制卡日期，不是疗程起止日期。`daily` 只有用户已确认每日固定安排时才为 true。`meal` 不明确时留空，在对话中继续核对，不从时钟时间推断饭前饭后。

宿主允许执行本地脚本且已具备 Python 3.10+、Pillow 和中文字体时，从 Skill 目录运行：

```sh
python3 scripts/render_card.py confirmed.json --out output
```

需要指定字体时使用 `--font /absolute/path/to/chinese-font.ttf`。脚本按原文生成 `medication-card.png` 和 `narration.txt`，保留精确时间、用量和吃饭关系；不将药物模型数量换算成用药剂量。每盒可通过 `extra_doses` 提供最多两条额外的已核对安排，每条含 `time`、`dose`、`meal`。`food_notes` 可保留已核对的食物注意事项。示例数据必须带 `demo: true` 并在卡片上显示“示例”。脚本不会覆盖已有输出。

朗读时逐项读出确认内容；不要为缩短时长删掉药名、用量或时段。宿主有 TTS 时可合成音频，并检查是否超过一分钟；如果完整内容太长，保留完整稿并告知时长，或在用户同意后分段。`narration.txt` 本身是文字文件，不是音频。

定时提醒需要宿主日历或提醒服务。核对时区、开始日期、重复规则以及需要的结束日期；仅在实际保存成功后报告“已设置”。示例卡不能创建真实提醒。不具备提醒工具时只交付安排，不宣称关闭网页后会提醒。把每日安排展示七天，不代表新开具了七天疗程。
